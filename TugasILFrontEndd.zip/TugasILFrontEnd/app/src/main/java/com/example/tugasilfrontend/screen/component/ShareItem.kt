package com.example.tugasilfrontend.screen.component

import android.content.Context
import android.content.Intent
import com.example.tugasilfrontend.R

fun shareItem(context: Context) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.frontcar_share))
    }

    context.startActivity(
        Intent.createChooser(
            intent,
            context.getString(R.string.frontcar_share)
        )
    )
}