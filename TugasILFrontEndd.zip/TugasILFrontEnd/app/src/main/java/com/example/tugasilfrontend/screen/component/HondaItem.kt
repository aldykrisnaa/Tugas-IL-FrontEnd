package com.example.tugasilfrontend.screen.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.tugasilfrontend.R
import com.example.tugasilfrontend.model.Honda
import com.example.tugasilfrontend.ui.theme.TugasILFrontEndTheme

@Composable
fun HondaItem(
    mobilHonda: Honda,
    modifier: (Any) -> Unit = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
    ) {
        Image(
            painter = painterResource(id = mobilHonda.photo),
            contentDescription = mobilHonda.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .clip(CircleShape)
                .size(80.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(text = mobilHonda.name, style = MaterialTheme.typography.titleMedium)
            Row {
                Text(text = mobilHonda.series, color = MaterialTheme.colorScheme.primary)
                Text(text = " - ${mobilHonda.price}")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun HondaItemPreview() {
    TugasILFrontEndTheme {
        HondaItem(
            mobilHonda = Honda(
                1,
                "Honda Brio Satya",
                R.drawable.satya,
                "Rp 179.000.000",
                R.drawable.satya
            )
        )
    }
}