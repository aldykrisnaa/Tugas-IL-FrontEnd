package com.example.tugasilfrontend.model

import android.provider.ContactsContract.CommonDataKinds.Email

data class About(
    val name: String,
    val Email: String,
    val instansi: String,
    val photo: Int,
    val jurusan: String
)