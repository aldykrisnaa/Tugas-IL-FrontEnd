package com.example.tugasilfrontend.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.tugasilfrontend.data.DummyData
import com.example.tugasilfrontend.model.Daihatsu
import com.example.tugasilfrontend.model.Honda
import com.example.tugasilfrontend.navigation.Screen
import com.example.tugasilfrontend.screen.component.DaihatsuItem
import com.example.tugasilfrontend.screen.component.HondaItem

@Composable
fun HomeScreen(
    navController: NavController,
    modifier: Modifier,
    mobilHonda: List<Honda> = DummyData.mobilHonda,
    mobilDaihatsu: List<Daihatsu> = DummyData.mobilDaihatsu,
)   {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier
    )   {
        item {
            LazyRow (
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = modifier
            ) {
                items(mobilHonda, key = { it.id }) {
                    HondaItem(mobilHonda = it) { mobilHondaId ->
                        navController.navigate(Screen.Detail.route + "/$mobilHondaId")
                    }
                }
            }
        }
                items(mobilDaihatsu, key = { it.id }) {
                    DaihatsuItem(mobilDaihatsu = it, modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}