package com.example.tugasilfrontend.data

import com.example.tugasilfrontend.R
import com.example.tugasilfrontend.model.Honda
import com.example.tugasilfrontend.model.Daihatsu
import com.example.tugasilfrontend.model.Toyota
import com.example.tugasilfrontend.model.About
import com.example.tugasilfrontend.model.Detail

object DummyData {
    val mobilHonda = listOf(
        Honda(
            id = 1,
            name = "Honda Brio",
            series = "Satya",
            price = "Rp 179.000.000",
            photo = R.drawable.satya
        ),
        Honda(
            id = 2,
            name = "Honda Brio",
            series = "RS",
            price = "Rp 208.000.000",
            photo = R.drawable.briors
        ),
        Honda(
            id = 3,
            name = "Honda HR-V",
            series = "-",
            price = "Rp 412.000.000",
            photo = R.drawable.hrv
        ),
        Honda(
            id = 4,
            name = "Honda City",
            series = "Hatchback",
            price = "Rp 357.000.000",
            photo = R.drawable.hatchback
        ),
        Honda(
            id = 5,
            name = "Honda City",
            series = "RS",
            price = "Rp 397.000.000",
            photo = R.drawable.cityrs
        ),
        Honda(
            id = 6,
            name = "Honda Civic",
            series = "Hatchback",
            price = "Rp 514.000.000",
            photo = R.drawable.civichtch
        ),
        Honda(
            id = 7,
            name = "Honda Civic",
            series = "Turbo",
            price = "Rp 633.000.000",
            photo = R.drawable.civicturbo
        ),
        Honda(
            id = 8,
            name = "Honda CR-V",
            series = "-",
            price = "Rp 712.000.000",
            photo = R.drawable.crv
        ),
        Honda(
            id = 9,
            name = "Honda Odyssey",
            series = "-",
            price = "Rp 899.000.000",
            photo = R.drawable.hondaodyssey
        ),
        Honda(
            id = 10,
            name = "Honda Accord",
            series = "-",
            price = "Rp 759.000.000",
            photo = R.drawable.hondaaccord
        )
    )

    val mobilDaihatsu = listOf(
        Daihatsu(
            id = 1,
            name = "Daihatsu Ayla",
            series = "-",
            price = "Rp 163.000.000",
            photo = R.drawable.ayla
        ),
        Daihatsu(
            id = 2,
            name = "Daihatsu Sigra",
            series = "-",
            price = "Rp 168.000.000",
            photo = R.drawable.sigra
        ),
        Daihatsu(
            id = 3,
            name = "Daihatsu Xenia",
            series = "-",
            price = "Rp 170.000.000",
            photo = R.drawable.xenia
        ),
        Daihatsu(
            id = 4,
            name = "Daihatsu Rocky",
            series = "-",
            price = "Rp 265.000.000",
            photo = R.drawable.rocky
        ),
        Daihatsu(
            id = 5,
            name = "Daihatsu Terios",
            series = "-",
            price = "Rp 268.000.000",
            photo = R.drawable.terios
        ),
        Daihatsu(
            id = 6,
            name = "Daihatsu Gran Max",
            series = "-",
            price = "Rp 211.000.000",
            photo = R.drawable.grandmax
        ),
        Daihatsu(
            id = 7,
            name = "Daihatsu Luxio",
            series = "-",
            price = "Rp 269.000.000",
            photo = R.drawable.luxio
        ),
        Daihatsu(
            id = 8,
            name = "Daihatsu Sirion",
            series = "X",
            price = "Rp 230.000.000",
            photo = R.drawable.sirion
        ),
        Daihatsu(
            id = 9,
            name = "Daihatsu Hi-Max",
            series = "M",
            price = "Rp 267.000.000",
            photo = R.drawable.himax
        ),
        Daihatsu(
            id = 10,
            name = "Daihatsu Gran Max",
            series = "Pick Up",
            price = "Rp 226.000.000",
            photo = R.drawable.grandmaxpu
        )
    )

    val mobilToyota = listOf(
        Toyota(
            id = 1,
            name = "Toyota Agya",
            series = "G",
            price = "Rp 170.000.000",
            photo = R.drawable.agya
        ),
        Toyota(
            id = 2,
            name = "Toyota Calya",
            series = "G MT",
            price = "Rp 167.000.000",
            photo = R.drawable.calya
        ),
        Toyota(
            id = 3,
            name = "Toyota Avanza",
            series = "Veloz",
            price = "Rp 239.000.000",
            photo = R.drawable.avanza
        ),
        Toyota(
            id = 4,
            name = "Toyota Raize",
            series = "G CVT",
            price = "Rp 238.000.000",
            photo = R.drawable.raize
        ),
        Toyota(
            id = 5,
            name = "Toyota Rush",
            series = "G CVT",
            price = "Rp 284.000.000",
            photo = R.drawable.rush
        ),
        Toyota(
            id = 6,
            name = "Toyota Kijang Innova",
            series = "G MT",
            price = "Rp 374.000.000",
            photo = R.drawable.innova
        ),
        Toyota(
            id = 7,
            name = "Toyota Fortuner",
            series = "G MT",
            price = "Rp 564.000.000",
            photo = R.drawable.fortuner
        ),
        Toyota(
            id = 8,
            name = "Toyota Corolla Cross",
            series = "H CVT",
            price = "Rp 466.000.000",
            photo = R.drawable.corolla
        ),
        Toyota(
            id = 9,
            name = " Toyota Camry",
            series = "2.5 G",
            price = "Rp 679.000.000",
            photo = R.drawable.camry
        ),
        Toyota(
            id = 10,
            name = "Toyota Land Cruiser",
            series = "VX",
            price = "Rp 2.244.000.000",
            photo = R.drawable.landcruiser
        )
    )

    val mobilAbout = listOf(
        About(
            name = "Muhammad Aldy Krisnanda",
            Email = "muhaldy2929@gmail.com",
            instansi = "Politeknik Negeri Bali",
            photo = R.drawable.aldy,
            jurusan = "Administrasi Bisnis"
        ),
    )

    val mobilDetail = listOf(
        Detail(
            id = 1,
            name = "Honda Brio",
            series = "Satya",
            price = "Rp 179.000.000",
            photo = R.drawable.satya,
        )
    )
}