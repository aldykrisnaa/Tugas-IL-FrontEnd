package com.example.tugasilfrontend.screen.component

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.tugasilfrontend.model.Daihatsu

@Composable
fun DaihatsuItem(
    mobilDaihatsu: Daihatsu,
    modifier: Modifier,
)