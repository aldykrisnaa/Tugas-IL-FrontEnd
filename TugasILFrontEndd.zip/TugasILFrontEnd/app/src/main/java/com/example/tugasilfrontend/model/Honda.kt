package com.example.tugasilfrontend.model

data class Honda(
    val id: Int,
    val name: String,
    val series: String,
    val price: String,
    val photo: Int,
)